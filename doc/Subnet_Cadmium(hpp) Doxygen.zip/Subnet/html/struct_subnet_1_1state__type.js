var struct_subnet_1_1state__type =
[
    [ "index", "struct_subnet_1_1state__type.html#aef32f9dae99946de914551b7e073d30e", null ],
    [ "packet", "struct_subnet_1_1state__type.html#a80bb693ccad684ce2a8dda264e89ca37", null ],
    [ "transmiting", "struct_subnet_1_1state__type.html#ac929b69c9d111d22158b5e808f56e8de", null ]
];