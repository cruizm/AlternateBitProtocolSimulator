var searchData=
[
  ['time_5fadvance_17',['time_advance',['../class_subnet.html#a660dd622ef74c7d4eddc51657943c230',1,'Subnet']]],
  ['transmiting_18',['transmiting',['../struct_subnet_1_1state__type.html#ac929b69c9d111d22158b5e808f56e8de',1,'Subnet::state_type']]]
];
