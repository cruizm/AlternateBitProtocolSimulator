var annotated_dup =
[
    [ "Subnet", "class_subnet.html", "class_subnet" ],
    [ "subnet_defs", "structsubnet__defs.html", [
      [ "in", "structsubnet__defs_1_1in.html", null ],
      [ "out", "structsubnet__defs_1_1out.html", null ]
    ] ]
];