var searchData=
[
  ['time_5fadvance_10',['time_advance',['../class_receiver.html#aedb53af510b5eec9410a2c416d318e51',1,'Receiver']]]
];
