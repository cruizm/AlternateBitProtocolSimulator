var class_application_gen =
[
    [ "ApplicationGen", "class_application_gen.html#ab06e8466334ad5234cf502fb6198c1e9", null ],
    [ "ApplicationGen", "class_application_gen.html#a68ccf7ca4e326ea883a5bd7eb488c66c", null ]
];