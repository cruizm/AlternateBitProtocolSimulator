var annotated_dup =
[
    [ "ApplicationGen", "class_application_gen.html", "class_application_gen" ],
    [ "inp_in", "structinp__in.html", null ],
    [ "outp_out", "structoutp__out.html", null ]
];