var annotated_dup =
[
    [ "ApplicationGen", "class_application_gen.html", "class_application_gen" ],
    [ "inp", "structinp.html", null ],
    [ "outp", "structoutp.html", null ]
];