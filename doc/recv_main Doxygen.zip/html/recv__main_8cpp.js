var recv__main_8cpp =
[
    [ "inp", "structinp.html", null ],
    [ "outp", "structoutp.html", null ],
    [ "ApplicationGen", "class_application_gen.html", "class_application_gen" ],
    [ "hclock", "recv__main_8cpp.html#a49149f534c2366ae290d9fa7131c8dc0", null ],
    [ "TIME", "recv__main_8cpp.html#a3893724880e0bfd3cabf4fceb0d0fb5d", null ]
];