var annotated_dup =
[
    [ "Receiver", "class_receiver.html", "class_receiver" ],
    [ "receiver_defs", "structreceiver__defs.html", [
      [ "in", "structreceiver__defs_1_1in.html", null ],
      [ "out", "structreceiver__defs_1_1out.html", null ]
    ] ]
];