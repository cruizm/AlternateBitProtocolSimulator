var searchData=
[
  ['sending_15',['sending',['../struct_receiver_1_1state__type.html#a07a73a253544ee613b92b04d1bf861f9',1,'Receiver::state_type']]],
  ['state_16',['state',['../class_receiver.html#a0f7134f8b7feeed79accc618b0eafc9c',1,'Receiver']]],
  ['state_5ftype_17',['state_type',['../struct_receiver_1_1state__type.html',1,'Receiver']]]
];
