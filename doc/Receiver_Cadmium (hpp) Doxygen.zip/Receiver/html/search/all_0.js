var searchData=
[
  ['ack_5fnum_0',['ack_num',['../struct_receiver_1_1state__type.html#ad4f666629f3c7dd68fb49808cc4e0611',1,'Receiver::state_type']]],
  ['alternate_20bit_20protocol_20code_20documentation_1',['Alternate Bit Protocol Code Documentation',['../index.html',1,'']]]
];
