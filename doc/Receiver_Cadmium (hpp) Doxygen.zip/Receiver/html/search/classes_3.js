var searchData=
[
  ['state_5ftype_23',['state_type',['../struct_receiver_1_1state__type.html',1,'Receiver']]]
];
