var searchData=
[
  ['input_5fports_35',['input_ports',['../class_receiver.html#abce078781615d9bbdd7704de2c06fc15',1,'Receiver']]]
];
