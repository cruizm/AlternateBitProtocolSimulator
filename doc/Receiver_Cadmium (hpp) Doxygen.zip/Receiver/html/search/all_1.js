var searchData=
[
  ['confluence_5ftransition_2',['confluence_transition',['../class_receiver.html#a101f2c622d87cc73a6bf2d22c4d0565d',1,'Receiver']]]
];
