var searchData=
[
  ['sending_33',['sending',['../struct_receiver_1_1state__type.html#a07a73a253544ee613b92b04d1bf861f9',1,'Receiver::state_type']]],
  ['state_34',['state',['../class_receiver.html#a0f7134f8b7feeed79accc618b0eafc9c',1,'Receiver']]]
];
