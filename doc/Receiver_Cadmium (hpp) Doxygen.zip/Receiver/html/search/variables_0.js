var searchData=
[
  ['ack_5fnum_31',['ack_num',['../struct_receiver_1_1state__type.html#ad4f666629f3c7dd68fb49808cc4e0611',1,'Receiver::state_type']]]
];
