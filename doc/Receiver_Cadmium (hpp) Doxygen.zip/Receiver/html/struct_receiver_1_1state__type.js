var struct_receiver_1_1state__type =
[
    [ "ack_num", "struct_receiver_1_1state__type.html#ad4f666629f3c7dd68fb49808cc4e0611", null ],
    [ "sending", "struct_receiver_1_1state__type.html#a07a73a253544ee613b92b04d1bf861f9", null ]
];