var files_dup =
[
    [ "receiver_cadmium.hpp", "receiver__cadmium_8hpp.html", [
      [ "receiver_defs", "structreceiver__defs.html", [
        [ "in", "structreceiver__defs_1_1in.html", null ],
        [ "out", "structreceiver__defs_1_1out.html", null ]
      ] ],
      [ "out", "structreceiver__defs_1_1out.html", null ],
      [ "in", "structreceiver__defs_1_1in.html", null ],
      [ "Receiver", "class_receiver.html", "class_receiver" ],
      [ "state_type", "struct_receiver_1_1state__type.html", "struct_receiver_1_1state__type" ]
    ] ]
];